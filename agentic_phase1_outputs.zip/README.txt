Files: pilot_dataset.csv, pilot_results_detailed.csv, csp_sweep.csv, csp_sweep.png, SUSPADR_flow.png, architecture.png, run_pilot.py
