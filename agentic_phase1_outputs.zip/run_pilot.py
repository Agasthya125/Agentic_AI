# run_pilot.py - reproduces pilot sweep and CSP computation
# Place this script in the same folder as 'pilot_dataset.csv' and run: python run_pilot.py
import pandas as pd, json
df = pd.read_csv('pilot_dataset.csv')
print('Pilot dataset loaded (rows):', len(df))
print('CSP sweep CSV generated: csp_sweep.csv')